﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Dashboard_STAFF
{
    public partial class RestockRequest : Form
    {
        string connString = "server=localhost;port=3306;database=techinventorydb;user=root;password=";
        public RestockRequest()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //SERIAL NO, ITEM NAME, BRAND NNAME, QUANTITY
        }
    }
}
