﻿namespace Dashboard_STAFF
{
    partial class RestockReqApproval_ADMIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            flowLayoutPanel1 = new FlowLayoutPanel();
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label5 = new Label();
            textBox5 = new TextBox();
            label6 = new Label();
            textBox4 = new TextBox();
            label7 = new Label();
            textBox6 = new TextBox();
            flowLayoutPanel2 = new FlowLayoutPanel();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            button1 = new Button();
            flowLayoutPanel1.SuspendLayout();
            flowLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(label1);
            flowLayoutPanel1.Controls.Add(label2);
            flowLayoutPanel1.Controls.Add(textBox1);
            flowLayoutPanel1.Controls.Add(label3);
            flowLayoutPanel1.Controls.Add(textBox2);
            flowLayoutPanel1.Controls.Add(label4);
            flowLayoutPanel1.Controls.Add(textBox3);
            flowLayoutPanel1.Controls.Add(label5);
            flowLayoutPanel1.Controls.Add(textBox5);
            flowLayoutPanel1.Controls.Add(label6);
            flowLayoutPanel1.Controls.Add(textBox4);
            flowLayoutPanel1.Controls.Add(label7);
            flowLayoutPanel1.Controls.Add(textBox6);
            flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel1.Location = new Point(12, 12);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Padding = new Padding(20);
            flowLayoutPanel1.Size = new Size(840, 386);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label1.Location = new Point(23, 20);
            label1.Name = "label1";
            label1.Padding = new Padding(0, 0, 0, 15);
            label1.Size = new Size(285, 47);
            label1.TabIndex = 0;
            label1.Text = "Restock Request Details";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(23, 67);
            label2.Name = "label2";
            label2.Size = new Size(110, 25);
            label2.TabIndex = 1;
            label2.Text = "Request ID:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(23, 95);
            textBox1.Margin = new Padding(3, 3, 60, 15);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(333, 31);
            textBox1.TabIndex = 2;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 141);
            label3.Name = "label3";
            label3.Size = new Size(99, 25);
            label3.TabIndex = 3;
            label3.Text = "Serial No.:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(23, 169);
            textBox2.Margin = new Padding(3, 3, 3, 15);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(333, 31);
            textBox2.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(23, 215);
            label4.Name = "label4";
            label4.Size = new Size(111, 25);
            label4.TabIndex = 5;
            label4.Text = "Item Name:";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(23, 243);
            textBox3.Margin = new Padding(3, 3, 3, 15);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(333, 31);
            textBox3.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(23, 289);
            label5.Name = "label5";
            label5.Size = new Size(187, 25);
            label5.TabIndex = 7;
            label5.Text = "Requested Quantity:";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(23, 317);
            textBox5.Margin = new Padding(3, 3, 3, 15);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(152, 31);
            textBox5.TabIndex = 13;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(419, 63);
            label6.Margin = new Padding(3, 43, 3, 0);
            label6.Name = "label6";
            label6.Size = new Size(131, 25);
            label6.TabIndex = 9;
            label6.Text = "Request Date:";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(419, 91);
            textBox4.Margin = new Padding(3, 3, 3, 15);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(333, 31);
            textBox4.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(419, 137);
            label7.Name = "label7";
            label7.Size = new Size(134, 25);
            label7.TabIndex = 11;
            label7.Text = "Current Stock:";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(419, 165);
            textBox6.Margin = new Padding(3, 3, 3, 15);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(111, 31);
            textBox6.TabIndex = 14;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Controls.Add(radioButton1);
            flowLayoutPanel2.Controls.Add(radioButton2);
            flowLayoutPanel2.Controls.Add(button1);
            flowLayoutPanel2.Location = new Point(222, 407);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Padding = new Padding(50, 20, 20, 20);
            flowLayoutPanel2.Size = new Size(465, 131);
            flowLayoutPanel2.TabIndex = 1;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            radioButton1.Location = new Point(53, 23);
            radioButton1.Margin = new Padding(3, 3, 70, 20);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(117, 32);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "Approve";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            radioButton2.Location = new Point(243, 23);
            radioButton2.Margin = new Padding(3, 3, 100, 3);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(96, 32);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "Reject";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.ForeColor = Color.FromArgb(43, 42, 76);
            button1.Location = new Point(50, 75);
            button1.Margin = new Padding(0);
            button1.Name = "button1";
            button1.Size = new Size(252, 46);
            button1.TabIndex = 2;
            button1.Text = "SUBMIT";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // RestockReqApproval_ADMIN
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(43, 42, 76);
            ClientSize = new Size(864, 550);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(flowLayoutPanel2);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            ForeColor = Color.White;
            Name = "RestockReqApproval_ADMIN";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "RestockRequestApproval";
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            flowLayoutPanel2.ResumeLayout(false);
            flowLayoutPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private FlowLayoutPanel flowLayoutPanel1;
        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private Label label3;
        private TextBox textBox2;
        private Label label4;
        private TextBox textBox3;
        private Label label5;
        private Label label6;
        private TextBox textBox4;
        private Label label7;
        private FlowLayoutPanel flowLayoutPanel2;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Button button1;
        private TextBox textBox5;
        private TextBox textBox6;
    }
}