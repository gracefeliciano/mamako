﻿namespace Dashboard_STAFF
{
    partial class SalesReturn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            purchaseOrders_btn = new Button();
            salesReturns_btn = new Button();
            salesOrders_btn = new Button();
            inventory_btn = new Button();
            comboBox2 = new ComboBox();
            home_btn = new Button();
            label1 = new Label();
            splitContainer1 = new SplitContainer();
            pictureBox4 = new PictureBox();
            button2 = new Button();
            pictureBox3 = new PictureBox();
            button3 = new Button();
            pictureBox2 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox5 = new PictureBox();
            itemGrp_btn = new Button();
            salesReturns_dataGridView = new DataGridView();
            ReturnID = new DataGridViewTextBoxColumn();
            item = new DataGridViewTextBoxColumn();
            Brand = new DataGridViewTextBoxColumn();
            Quantity = new DataGridViewTextBoxColumn();
            TotalPrice = new DataGridViewTextBoxColumn();
            ReturnDate = new DataGridViewTextBoxColumn();
            Reason = new DataGridViewTextBoxColumn();
            notify_pictureBox = new PictureBox();
            orgName_label = new Label();
            search_textBox = new TextBox();
            flowLayoutPanel4 = new FlowLayoutPanel();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)salesReturns_dataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)notify_pictureBox).BeginInit();
            flowLayoutPanel4.SuspendLayout();
            SuspendLayout();
            // 
            // purchaseOrders_btn
            // 
            purchaseOrders_btn.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            purchaseOrders_btn.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            purchaseOrders_btn.FlatAppearance.BorderSize = 0;
            purchaseOrders_btn.FlatStyle = FlatStyle.Flat;
            purchaseOrders_btn.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            purchaseOrders_btn.ForeColor = Color.White;
            purchaseOrders_btn.Location = new Point(3, 420);
            purchaseOrders_btn.Name = "purchaseOrders_btn";
            purchaseOrders_btn.Size = new Size(295, 36);
            purchaseOrders_btn.TabIndex = 6;
            purchaseOrders_btn.Text = "           Purchase Orders";
            purchaseOrders_btn.TextAlign = ContentAlignment.MiddleLeft;
            purchaseOrders_btn.UseVisualStyleBackColor = true;
            purchaseOrders_btn.Click += purchaseOrders_btn_Click;
            // 
            // salesReturns_btn
            // 
            salesReturns_btn.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            salesReturns_btn.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            salesReturns_btn.FlatAppearance.BorderSize = 0;
            salesReturns_btn.FlatStyle = FlatStyle.Flat;
            salesReturns_btn.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            salesReturns_btn.ForeColor = Color.White;
            salesReturns_btn.Location = new Point(0, 340);
            salesReturns_btn.Name = "salesReturns_btn";
            salesReturns_btn.Size = new Size(300, 36);
            salesReturns_btn.TabIndex = 5;
            salesReturns_btn.Text = "            Sales Returns";
            salesReturns_btn.TextAlign = ContentAlignment.MiddleLeft;
            salesReturns_btn.UseVisualStyleBackColor = true;
            salesReturns_btn.Click += salesReturns_btn_Click;
            // 
            // salesOrders_btn
            // 
            salesOrders_btn.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            salesOrders_btn.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            salesOrders_btn.FlatAppearance.BorderSize = 0;
            salesOrders_btn.FlatStyle = FlatStyle.Flat;
            salesOrders_btn.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            salesOrders_btn.ForeColor = Color.White;
            salesOrders_btn.Location = new Point(0, 263);
            salesOrders_btn.Name = "salesOrders_btn";
            salesOrders_btn.Size = new Size(310, 36);
            salesOrders_btn.TabIndex = 4;
            salesOrders_btn.Text = "            Sales Orders";
            salesOrders_btn.TextAlign = ContentAlignment.MiddleLeft;
            salesOrders_btn.UseVisualStyleBackColor = true;
            salesOrders_btn.Click += salesOrders_btn_Click;
            // 
            // inventory_btn
            // 
            inventory_btn.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            inventory_btn.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            inventory_btn.FlatAppearance.BorderSize = 0;
            inventory_btn.FlatStyle = FlatStyle.Flat;
            inventory_btn.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            inventory_btn.ForeColor = Color.White;
            inventory_btn.Location = new Point(0, 188);
            inventory_btn.Name = "inventory_btn";
            inventory_btn.Size = new Size(300, 36);
            inventory_btn.TabIndex = 2;
            inventory_btn.Text = "            Inventory";
            inventory_btn.TextAlign = ContentAlignment.MiddleLeft;
            inventory_btn.UseVisualStyleBackColor = true;
            inventory_btn.Click += inventory_btn_Click;
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            comboBox2.ForeColor = Color.FromArgb(43, 42, 76);
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(12, 61);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(151, 28);
            comboBox2.TabIndex = 5;
            comboBox2.Text = "FILTER";
            // 
            // home_btn
            // 
            home_btn.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            home_btn.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            home_btn.FlatAppearance.BorderSize = 0;
            home_btn.FlatStyle = FlatStyle.Flat;
            home_btn.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            home_btn.ForeColor = Color.White;
            home_btn.Location = new Point(0, 112);
            home_btn.Name = "home_btn";
            home_btn.Size = new Size(304, 36);
            home_btn.TabIndex = 1;
            home_btn.Text = "            Home";
            home_btn.TextAlign = ContentAlignment.MiddleLeft;
            home_btn.UseVisualStyleBackColor = true;
            home_btn.Click += home_btn_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(302, 30);
            label1.TabIndex = 0;
            label1.Text = "INVENTORY MANAGEMENT";
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = Color.FromArgb(43, 42, 76);
            splitContainer1.Panel1.Controls.Add(pictureBox4);
            splitContainer1.Panel1.Controls.Add(button2);
            splitContainer1.Panel1.Controls.Add(pictureBox3);
            splitContainer1.Panel1.Controls.Add(button3);
            splitContainer1.Panel1.Controls.Add(pictureBox2);
            splitContainer1.Panel1.Controls.Add(pictureBox7);
            splitContainer1.Panel1.Controls.Add(pictureBox6);
            splitContainer1.Panel1.Controls.Add(purchaseOrders_btn);
            splitContainer1.Panel1.Controls.Add(pictureBox1);
            splitContainer1.Panel1.Controls.Add(salesReturns_btn);
            splitContainer1.Panel1.Controls.Add(pictureBox5);
            splitContainer1.Panel1.Controls.Add(salesOrders_btn);
            splitContainer1.Panel1.Controls.Add(itemGrp_btn);
            splitContainer1.Panel1.Controls.Add(inventory_btn);
            splitContainer1.Panel1.Controls.Add(home_btn);
            splitContainer1.Panel1.Controls.Add(label1);
            splitContainer1.Panel1.Paint += splitContainer1_Panel1_Paint;
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(flowLayoutPanel4);
            splitContainer1.Panel2.Controls.Add(salesReturns_dataGridView);
            splitContainer1.Panel2.Controls.Add(comboBox2);
            splitContainer1.Panel2.Controls.Add(notify_pictureBox);
            splitContainer1.Panel2.Controls.Add(orgName_label);
            splitContainer1.Panel2.Controls.Add(search_textBox);
            splitContainer1.Panel2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            splitContainer1.Size = new Size(1539, 840);
            splitContainer1.SplitterDistance = 313;
            splitContainer1.TabIndex = 3;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.report_removebg_preview1;
            pictureBox4.Location = new Point(12, 501);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(50, 30);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 45;
            pictureBox4.TabStop = false;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            button2.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(124, 737);
            button2.Name = "button2";
            button2.Size = new Size(153, 36);
            button2.TabIndex = 29;
            button2.Text = "Shaine Bambico";
            button2.TextAlign = ContentAlignment.MiddleLeft;
            button2.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.basket_removebg_preview;
            pictureBox3.Location = new Point(12, 423);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(50, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 44;
            pictureBox3.TabStop = false;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            button3.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI Light", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(116, 751);
            button3.Name = "button3";
            button3.Size = new Size(179, 76);
            button3.TabIndex = 30;
            button3.Text = "shaineangeloubambico\r\n@gmail.com";
            button3.TextAlign = ContentAlignment.MiddleLeft;
            button3.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.returns_removebg_preview;
            pictureBox2.Location = new Point(12, 344);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(50, 30);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 43;
            pictureBox2.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox7.BorderStyle = BorderStyle.FixedSingle;
            pictureBox7.Image = Properties.Resources.c29b44ca_e825_4217_b7e6_f6825e0fa03a;
            pictureBox7.Location = new Point(18, 740);
            pictureBox7.Margin = new Padding(15, 3, 3, 3);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(92, 87);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 28;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.imgbin_shopping_cart_computer_icons_white_cart_simple_white_shopping_cart_illustration_nDJVn3nE6gpyZGMq8spPi2dy0_removebg_preview;
            pictureBox6.Location = new Point(12, 267);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(50, 30);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 42;
            pictureBox6.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.stock_inventory_icon_15;
            pictureBox1.Location = new Point(12, 192);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 41;
            pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.whitebtn;
            pictureBox5.Location = new Point(12, 116);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(50, 30);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 40;
            pictureBox5.TabStop = false;
            // 
            // itemGrp_btn
            // 
            itemGrp_btn.Location = new Point(0, 0);
            itemGrp_btn.Name = "itemGrp_btn";
            itemGrp_btn.Size = new Size(75, 23);
            itemGrp_btn.TabIndex = 46;
            // 
            // salesReturns_dataGridView
            // 
            salesReturns_dataGridView.AllowUserToAddRows = false;
            salesReturns_dataGridView.AllowUserToDeleteRows = false;
            salesReturns_dataGridView.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            salesReturns_dataGridView.BackgroundColor = Color.FromArgb(238, 226, 222);
            salesReturns_dataGridView.BorderStyle = BorderStyle.None;
            salesReturns_dataGridView.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            salesReturns_dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            salesReturns_dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            salesReturns_dataGridView.Columns.AddRange(new DataGridViewColumn[] { ReturnID, item, Brand, Quantity, TotalPrice, ReturnDate, Reason });
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Window;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            dataGridViewCellStyle4.ForeColor = Color.FromArgb(43, 42, 76);
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            salesReturns_dataGridView.DefaultCellStyle = dataGridViewCellStyle4;
            salesReturns_dataGridView.Location = new Point(12, 115);
            salesReturns_dataGridView.Name = "salesReturns_dataGridView";
            salesReturns_dataGridView.ReadOnly = true;
            salesReturns_dataGridView.RowHeadersVisible = false;
            salesReturns_dataGridView.RowHeadersWidth = 51;
            salesReturns_dataGridView.ScrollBars = ScrollBars.Horizontal;
            salesReturns_dataGridView.Size = new Size(1197, 619);
            salesReturns_dataGridView.TabIndex = 9;
            // 
            // ReturnID
            // 
            ReturnID.HeaderText = "ID";
            ReturnID.MinimumWidth = 6;
            ReturnID.Name = "ReturnID";
            ReturnID.ReadOnly = true;
            ReturnID.Width = 50;
            // 
            // item
            // 
            item.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            item.HeaderText = "Item";
            item.MinimumWidth = 300;
            item.Name = "item";
            item.ReadOnly = true;
            // 
            // Brand
            // 
            Brand.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Brand.HeaderText = "Brand";
            Brand.MinimumWidth = 200;
            Brand.Name = "Brand";
            Brand.ReadOnly = true;
            // 
            // Quantity
            // 
            Quantity.HeaderText = "Quantity";
            Quantity.MinimumWidth = 90;
            Quantity.Name = "Quantity";
            Quantity.ReadOnly = true;
            Quantity.Width = 90;
            // 
            // TotalPrice
            // 
            TotalPrice.HeaderText = "Total Price";
            TotalPrice.MinimumWidth = 80;
            TotalPrice.Name = "TotalPrice";
            TotalPrice.ReadOnly = true;
            TotalPrice.Width = 90;
            // 
            // ReturnDate
            // 
            ReturnDate.HeaderText = "Return Date";
            ReturnDate.MinimumWidth = 6;
            ReturnDate.Name = "ReturnDate";
            ReturnDate.ReadOnly = true;
            ReturnDate.Width = 125;
            // 
            // Reason
            // 
            Reason.HeaderText = "Reason";
            Reason.MinimumWidth = 180;
            Reason.Name = "Reason";
            Reason.ReadOnly = true;
            Reason.Width = 180;
            // 
            // notify_pictureBox
            // 
            notify_pictureBox.BackColor = Color.Transparent;
            notify_pictureBox.Cursor = Cursors.Hand;
            notify_pictureBox.Image = Properties.Resources._565422;
            notify_pictureBox.Location = new Point(1049, 21);
            notify_pictureBox.Name = "notify_pictureBox";
            notify_pictureBox.Size = new Size(30, 30);
            notify_pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            notify_pictureBox.TabIndex = 4;
            notify_pictureBox.TabStop = false;
            // 
            // orgName_label
            // 
            orgName_label.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            orgName_label.AutoSize = true;
            orgName_label.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            orgName_label.Location = new Point(1108, 28);
            orgName_label.Name = "orgName_label";
            orgName_label.RightToLeft = RightToLeft.Yes;
            orgName_label.Size = new Size(85, 23);
            orgName_label.TabIndex = 2;
            orgName_label.Text = "C-SHARK";
            // 
            // search_textBox
            // 
            search_textBox.Font = new Font("Segoe UI", 9F);
            search_textBox.ForeColor = Color.FromArgb(43, 42, 76);
            search_textBox.Location = new Point(12, 12);
            search_textBox.Name = "search_textBox";
            search_textBox.PlaceholderText = "Search";
            search_textBox.Size = new Size(318, 27);
            search_textBox.TabIndex = 0;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.BackColor = Color.FromArgb(238, 226, 222);
            flowLayoutPanel4.Controls.Add(button1);
            flowLayoutPanel4.Location = new Point(3, 742);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Padding = new Padding(20);
            flowLayoutPanel4.Size = new Size(1216, 95);
            flowLayoutPanel4.TabIndex = 10;
            // 
            // button1
            // 
            button1.ForeColor = Color.FromArgb(43, 42, 76);
            button1.Location = new Point(23, 23);
            button1.Margin = new Padding(3, 3, 3, 18);
            button1.Name = "button1";
            button1.Size = new Size(277, 50);
            button1.TabIndex = 0;
            button1.Text = "Request Return Item";
            button1.UseVisualStyleBackColor = true;
            // 
            // SalesReturn
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 226, 222);
            ClientSize = new Size(1539, 840);
            Controls.Add(splitContainer1);
            Name = "SalesReturn";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SalesReturn";
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)salesReturns_dataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)notify_pictureBox).EndInit();
            flowLayoutPanel4.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Button purchaseOrders_btn;
        private Button salesReturns_btn;
        private Button salesOrders_btn;
        private Button inventory_btn;
        private ComboBox comboBox2;
        private Button home_btn;
        private Label label1;
        private SplitContainer splitContainer1;
        private PictureBox notify_pictureBox;
        private Label orgName_label;
        private TextBox search_textBox;
        private DataGridView salesReturns_dataGridView;
        private DataGridViewTextBoxColumn ReturnID;
        private DataGridViewTextBoxColumn item;
        private DataGridViewTextBoxColumn Brand;
        private DataGridViewTextBoxColumn Quantity;
        private DataGridViewTextBoxColumn TotalPrice;
        private DataGridViewTextBoxColumn ReturnDate;
        private DataGridViewTextBoxColumn Reason;
        private Button itemGrp_btn;
        private Button button2;
        private Button button3;
        private PictureBox pictureBox7;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox6;
        private PictureBox pictureBox1;
        private PictureBox pictureBox5;
        private FlowLayoutPanel flowLayoutPanel4;
        private Button button1;
    }
}